function v = last_speed(x, static_data)

% evaluate the sailing speed on the last leg
% given the sailing speeds on the previous legs, 
% the length of the legs and the total traveling time
% and the sea currents

known_time = sum(static_data.length_of_arcs(1:end-1) ./ (x + static_data.sea_currents(1:end-1)));
rest_time = static_data.travel_time - known_time;
v =  static_data.length_of_arcs(end) / rest_time - static_data.sea_currents(end);
