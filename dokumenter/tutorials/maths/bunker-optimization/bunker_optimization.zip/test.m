%
% script to illustrate the optimal speed calculation for a vessel on an itinerary with varying sea currents
%

more off
clear

static_data.length_of_arcs = [20, 20, 20]' %nm

static_data.sea_currents = [0 -3 3]' %kts

static_data.travel_time = 3 %hours

static_data.constant_speed = 0 % whether we want the speed (power) to be constant

x0 = [23; 20];
c = bunker_consumption(x0, static_data) %just to have a look at what the bunker consumption calculation function looks like


[paramv_opt, err, l, C_vals] = optimise_fun2('bunker_consumption', 'jac_bunker_consumption', [], [], static_data, x0, 30, .0001, 1e6*eps );

%output the bunker consumption function at the optimum
c_check = bunker_consumption(paramv_opt, static_data)

%test that the travelling times sum up to the total traveling time
static_data.length_of_arcs ./ ([paramv_opt; last_speed(paramv_opt,static_data)] + static_data.sea_currents) %distances ./ GPS speeds 


%investigate the neighborhood around optimum (for the 3-leg, i.e. 2-variable, case)
%should clearly indicate a well defined optimum

n = 50;
err_map = zeros(n);
for i= 1:n,
  for j = 1:n
    err_map(i,j) = bunker_consumption(paramv_opt + [i/n-.5; j/n-.5], static_data);
  endfor
endfor
imagesc(err_map);

