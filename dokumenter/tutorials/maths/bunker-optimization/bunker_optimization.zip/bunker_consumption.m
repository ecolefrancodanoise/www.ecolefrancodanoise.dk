
function obj = bunker_consumption(x, static_data)
%
% x contains the sailing speeds for each segment except the last one
%

  persistent v = [
    10  10.5    11  11.5    12  12.5    13  13.5    14  14.5    15  15.5    16  16.5    17  17.5    18  18.5    19  19.5    20  ...
      20.5    21  21.5    22  22.5    23  23.5    24  24.5    25  25.5
  ];  # knots

  persistent bunker_curve = [31.93   36.04   40.55   45.47   50.82   56.61   62.86   69.56   76.72   84.39   92.55   101.19  110.28  119.83  129.31  140.24  151.69  162.71  174.1   184.89  195.94  ...
      206.82  217.93  229.67  241.76  255.43  269.84  286.96  305.67  328.7   355.14 NA ]

  final_speed = last_speed(x, static_data);

  x_all = [x; final_speed];

  fuel_points = interp1(v, bunker_curve, x_all);
  %bunker consumption for each segment and obj(end) is the difference with required arrival time
  obj = sum(static_data.length_of_arcs ./ (x_all + static_data.sea_currents) .* fuel_points / 24); %length / travel_speed * consumption_per_hour
  if static_data.constant_speed == 1
    obj = [obj; 1e5*diff(x_all)];
  endif
endfunction
