%
% The Jacobian of the bunker consumption function
%

function J = jac_bunker_consumption(x0,static_data,d)

  J = jac_num('bunker_consumption',x0,static_data,d);

endfunction
