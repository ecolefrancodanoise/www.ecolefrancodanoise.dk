function [X_opt, err_old, lambda,Xvals] = optimise_fun2(fun, Jfun, solve_fun, update_fun, static_data, X0, max_nb_iter, lambda0, tol)
%function [X_opt, err_old, lambda,Xvals] = optimise_fun(fun, Jfun, solve_fun, update_fun, static_data, X0, max_nb_iter, lambda0, tol)
%Levenberg Marquardt minimiser

  X_opt = X0;
  err_old = norm(feval(fun,X0,static_data))
  lambda = lambda0;
  ok_counter = 0;
  Xvals = X0;
  nb_iter = 0;
  done = 0;

while(~done),
  J= feval(Jfun, X_opt, static_data,1000*eps);
  sizeJ = size(J,2);

  if isempty(solve_fun)
    JtJ = J'*J;
%JtJ
%keyboard

    if issparse(J),%default solving of the LM-step, i.e. uniform damping
      damping_vec = ones(sizeJ,1);

      lambda_diag = lambda*sparse(1:sizeJ,1:sizeJ, damping_vec);
      d = spinv(JtJ+lambda_diag)*J'*feval(fun,X_opt,static_data);
    else
      d = inv(JtJ+lambda*eye(size(JtJ)))*J'*feval(fun,X_opt,static_data);
    end
  else
    err = feval(fun, X_opt, static_data);
    d = feval(solve_fun, err, J, static_data, lambda);

  end
  if ~isempty(update_fun), %if we need special update rules
    X_opt_tmp = feval(update_fun,{X_opt,d,static_data});
  else %if we are just using the usual LM-update
  X_opt_tmp = X_opt-d;
  end
  err_tmp = norm(feval(fun, X_opt_tmp, static_data))

  if lambda > 1e16, done = 1; end
  if err_tmp < 1e-11, done = 1; end

 if err_tmp <= err_old,
    de = norm(err_old-err_tmp);
    if de<tol, return, end
    err_old= err_tmp;
    ok_counter =ok_counter+1;
    X_opt = X_opt_tmp;
    nb_iter = nb_iter + 1; 
    if nb_iter>=max_nb_iter, done = 1; end
    Xvals = [Xvals, X_opt];
    [nb_iter, err_tmp,log10(de), lambda]
    if ok_counter >3,%20
      lambda=lambda/1.5; %1.4
      ok_counter = 0;
    end
  else
    lambda = 2*lambda;
    ok_counter = 0;
  end
end

